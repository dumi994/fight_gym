<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Course;
use App\Models\User;


class CourseController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        $courses = Course::all();
        return view('admin.courses.index', compact('courses'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        // Recupera solo gli utenti con ruolo "trainer"
        $trainers = User::whereDoesntHave('roles', function ($query) {
            $query->where('name', 'admin');
        })->get();
        return view('admin.courses.create', compact('trainers'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'title' => 'required|unique:courses|max:255',
            'duration' => 'nullable|date_format:H:i',
            'state' => 'required',
            'course_start' => 'nullable|date_format:H:i',
            'course_end' => 'nullable|date_format:H:i',
            'price' => 'nullable|numeric',
            'level' => 'nullable',
            'days' => 'nullable',
            'teacher_id' => 'required|exists:users,id'
        ]);

        Course::create($request->all());

        return redirect()->route('courses.index')->with('success', 'Nuovo corso aggiunto con successo!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Course $course)
    {
        $trainers = User::whereDoesntHave('roles', function ($query) {
            $query->where('name', 'admin');
        })->get();
        return view('admin.courses.edit', compact('course', 'trainers'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Course $course)
    {
        $request->merge([
            'duration' => $request->input('duration') ? substr($request->input('duration'), 0, 5) : null,
            'course_start' => $request->input('course_start') ? substr($request->input('course_start'), 0, 5) : null,
            'course_end' => $request->input('course_end') ? substr($request->input('course_end'), 0, 5) : null,
        ]);

        // Esegui la validazione
        $request->validate([
            'title' => 'required|max:255',
            'duration' => 'nullable|date_format:H:i',
            'state' => 'required',
            'course_start' => 'nullable|date_format:H:i',
            'course_end' => 'nullable|date_format:H:i',
            'price' => 'nullable|numeric',
            'level' => 'nullable',
            'days' => 'nullable'
        ]);
        $course->update($request->all());
        return redirect()->route('courses.index')->with('Corso aggiornato con successo!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
