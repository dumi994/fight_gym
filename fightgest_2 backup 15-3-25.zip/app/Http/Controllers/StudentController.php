<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Storage;
use App\Models\Student;
use App\Models\User;


use Illuminate\Http\Request;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $students = Student::all();

        return view('admin.students.index', compact('students'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $users = User::all();
        return view('admin.students.create', compact('users'));
    }


    /**
     * Store a newly created resource in storage.
     */


    public function store(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'birth_date' => 'required|date',
            'gender' => 'nullable|in:M,F,Altro',
            'address' => 'nullable|string',
            'phone_number' => 'nullable|string',
            'email' => 'required|email|unique:students,email',
            'medical_certificate_path' => 'nullable|file|mimes:pdf|max:2048',
            'enrollment_date' => 'nullable|date',
            'membership_status' => 'nullable|in:active,inactive,pending',
            'user_id' => 'required|exists:users,id',
        ]);

        // Creazione dello studente
        $student = new Student($request->all());
        $student->save();

        // Ripulisci il nome e il cognome da spazi
        $directory = "public/students/{$student->id}";
        Storage::makeDirectory($directory);

        // Gestione del file del certificato medico
        if ($request->hasFile('medical_certificate_path')) {
            $currentYear = date('Y'); // Ottieni l'anno corrente

            // Ottieni l'estensione originale del file
            $originalExtension = $request->file('medical_certificate_path')->getClientOriginalExtension();

            // Crea il nome del file con l'estensione originale
            $fileName = "{$student->first_name}_{$student->last_name}_certificate_{$currentYear}.{$originalExtension}";

            // Salva il file con il nuovo nome nella cartella specificata
            $filePath = $request->file('medical_certificate_path')->storeAs($directory, $fileName);
            $student->medical_certificate_path = $filePath; // Salva il percorso nel modello
            $student->save(); // Aggiorna il percorso del file
        }

        return redirect()->route('students.index')->with('success', 'Nuovo allievo aggiunto.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Student $student)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $users = User::all();
        $student = Student::findOrFail($id);
        return view('admin.students.edit', compact('student', 'users'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Student $student)
    {
        // Validazione dei dati in arrivo
        $request->validate([
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'birth_date' => 'required|date',
            'gender' => 'nullable|in:M,F,Altro',
            'address' => 'nullable|string',
            'phone_number' => 'nullable|string',
            'email' => 'required|email|unique:students,email,' . $student->id,
            'medical_certificate_path' => 'nullable|file|mimes:pdf|max:2048',
            'enrollment_date' => 'nullable|date',
            'membership_status' => 'nullable|in:active,inactive,pending',
            'user_id' => 'required|exists:users,id',
        ]);

        // Aggiornamento dei campi base
        $student->update($request->except('medical_certificate_path'));

        // Gestione dell'aggiornamento del certificato medico
        if ($request->hasFile('medical_certificate_path')) {
            $directory = "public/students/{$student->id}";

            // Se esiste un vecchio certificato, lo cancelliamo
            if ($student->medical_certificate_path) {
                Storage::delete($student->medical_certificate_path);
            }

            $currentYear = date('Y');
            $originalExtension = $request->file('medical_certificate_path')->getClientOriginalExtension();
            /*  $fileName = "{$student->id}_certificate_{$currentYear}.{$originalExtension}"; */
            $fileName = "{$student->first_name}_{$student->last_name}_certificate_{$currentYear}.{$originalExtension}";

            // Salva il nuovo file
            Storage::makeDirectory($directory);
            $filePath = $request->file('medical_certificate_path')->storeAs($directory, $fileName);
            $student->medical_certificate_path = $filePath;
        }

        // Salva le modifiche
        $student->save();

        return redirect()->route('students.index')->with('success', 'Allievo aggiornato con successo!');
    }



    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Student $student)
    {
        // Controlla se lo studente ha un certificato medico e lo elimina
        if ($student->medical_certificate_path) {
            // Ottieni la directory basata sull'ID dello studente
            $directory = "public/{$student->id}";

            // Elimina il certificato medico
            Storage::delete($student->medical_certificate_path);

            // Se la directory è vuota dopo la cancellazione del file, elimina anche la directory
            if (Storage::files($directory) === [] && Storage::directories($directory) === []) {
                Storage::deleteDirectory($directory);
            }
        }

        // Elimina il record dello studente dal database
        $student->delete();

        return redirect()->route('students.index')->with('delete', 'Allievo eliminato con successo!');
    }
}
