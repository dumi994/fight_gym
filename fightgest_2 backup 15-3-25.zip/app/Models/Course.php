<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    use HasFactory;

    // Definire la tabella se non segue il naming convenzionale
    protected $table = 'courses';

    // I campi che possono essere riempiti tramite mass assignment
    protected $fillable = [
        'title',
        'duration',
        'state',
        'course_start',
        'course_end',
        'price',
        'level',
        'days',
        'teacher_id'
    ];

    // Definire le relazioni
    public function users()
    {
        return $this->belongsToMany(User::class, 'course_user', 'course_id', 'user_id');
    }
}
