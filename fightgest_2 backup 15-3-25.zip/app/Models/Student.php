<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    use HasFactory;
    protected $fillable = [
        'first_name',
        'last_name',
        'birth_date',
        'gender',
        'address',
        'phone_number',
        'email',
        'medical_certificate_path',
        'enrollment_date',
        'membership_status',
        'user_id',
        /*  '_token',  */
    ];
}
